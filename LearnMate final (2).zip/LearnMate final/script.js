// --- DOM Elements ---
const loginContainer = document.getElementById('login-container');
const chatContainer = document.getElementById('chat-container');
const loginBtn = document.getElementById('login-btn');
const usernameInput = document.getElementById('username');

const displayUsername = document.getElementById('display-username');
const levelDisplay = document.getElementById('level-display');
const xpText = document.getElementById('xp-text');
const xpBar = document.getElementById('xp-bar');
const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const modeBtns = document.querySelectorAll('.mode-btn');
const diffBtns = document.querySelectorAll('.diff-btn');

// --- Application State ---
let currentMode = 'text'; 
let currentDiff = 'inter'; 
let lastTopic = ""; 
let userStats = { xp: 0, level: 1, topicLevels: {} };

// --- 1. The Master Curriculum Database ---
const curriculumDB = {
    "dsa": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Imagine you have a giant bedroom filled with thousands of toys all over the floor.</p>
                       <p>If your mom asks you to find one specific red racecar, it would take you a very long time because everything is a mess!</p>
                       <p>In the computer world, toys are called "Data." If the computer keeps data in a messy pile, it runs very slow.</p>
                       <p>Data Structures are like magical organizing boxes. You can put all your cars in one box, blocks in another, and action figures on a shelf.</p>
                       <p>Algorithms are simply the step-by-step instructions on how to find the toys. Like saying, "Walk to the shelf, look at the top row, grab the car."</p>
                       <p>One type of magical box is called a "Stack." Think of a stack of pancakes. You have to eat the top pancake before you can reach the bottom one!</p>
                       <p>Another box is a "Queue." This is exactly like waiting in line for a rollercoaster. The first person in the line gets to ride first.</p>
                       <p>When you put Data Structures and Algorithms together, the computer becomes a super-fast organizer that never loses anything.</p>
                       <p>By learning this, you are basically learning how to clean up the computer's messy bedroom so it can play games lightning fast!</p>`,
                
                // INTER: 4-5 Paragraphs of technical explanation
                inter: `<p>DSA stands for Data Structures and Algorithms. It is the fundamental building block of computer science, focusing on how to store, organize, and retrieve data efficiently in a machine's memory.</p>
                        <p>A Data Structure is a specialized format for organizing and storing data. Linear structures like Arrays and Linked Lists store data sequentially, while non-linear structures like Trees and Graphs manage hierarchical and interconnected data.</p>
                        <p>An Algorithm is a finite sequence of well-defined instructions used to solve a class of problems or perform a computation. We measure the efficiency of these algorithms using Big-O notation, which calculates the worst-case scenario for time and space complexity.</p>
                        <p>For example, a "Stack" utilizes a LIFO (Last In, First Out) principle, which is how your browser's "Back" button works. A "Queue" uses FIFO (First In, First Out), which is how a printer schedules documents. Mastering these ensures your applications scale without crashing under heavy loads.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>DSA (Data Structures & Algorithms)</strong> is the science of optimizing memory and processing speed. Data structures (Arrays, Trees, Hash Maps) organize data in memory, while algorithms (Sorting, Searching) provide the step-by-step computational logic to manipulate that data. Efficiency is measured via Big-O notation to evaluate time (speed) and space (memory) complexity.</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the simple analogy, what does the 'messy bedroom of toys' represent?", options: ["A fast computer", "Unorganized Data", "A Queue"], ans: 1 },
            { q: "What is the primary goal of Data Structures?", options: ["To make the screen brighter", "To organize and store data efficiently", "To delete viruses"], ans: 1 },
            { q: "Which real-world analogy best describes a 'Stack'?", options: ["A stack of pancakes", "Waiting in line for a rollercoaster", "A messy toy box"], ans: 0 },
            { q: "Which real-world analogy best describes a 'Queue'?", options: ["Eating the top pancake", "Waiting in line for a ride", "Looking for a red car"], ans: 1 },
            { q: "What does 'LIFO' stand for?", options: ["Last In, First Out", "Late In, Fast Out", "Left In, Found Out"], ans: 0 },
            { q: "Which data structure is used for a web browser's 'Back' button?", options: ["Queue", "Stack", "Array"], ans: 1 },
            { q: "What does 'FIFO' stand for?", options: ["First In, First Out", "Fast In, Fast Out", "First In, Found Out"], ans: 0 },
            { q: "How do we measure the efficiency of an algorithm?", options: ["Using a stopwatch", "Big-O Notation", "Megabytes"], ans: 1 },
            { q: "Arrays and Linked Lists are examples of what type of structure?", options: ["Non-linear", "Linear", "Magical"], ans: 1 },
            { q: "What evaluates both the time (speed) and space (memory) complexity?", options: ["Big-O Notation", "A Stack", "A Queue"], ans: 0 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Data Structures (Storage)</div>
                    <div class="flow-arrow">⬇️ Optimizes</div>
                    <div class="flow-node">Memory Management</div>
                    <div class="flow-arrow">➕ Combined with</div>
                    <div class="flow-node">Algorithms (Logic)</div>
                    <div class="flow-arrow">⬇️ Results in</div>
                    <div class="flow-node">Lightning Fast Software</div>
                 </div>`
    },
    "photosynthesis": {
        levels: [
            {
                baby: `<p>Did you know that plants get hungry and thirsty just like you do?</p>
                       <p>But plants don't have mouths, so they can't eat pizza or drink juice.</p>
                       <p>Instead, they have magic superpower roots that drink water hidden deep down in the dirt.</p>
                       <p>They also have green leaves that act like solar panels to catch warm sunlight from the sky.</p>
                       <p>When we breathe out, we push out a gas called carbon dioxide, which plants actually love to breathe in!</p>
                       <p>Inside their leaves, plants mix the water, the sunlight, and the carbon dioxide together like a recipe.</p>
                       <p>This magic recipe creates sweet sugar, which is the exact food the plant needs to grow big and strong.</p>
                       <p>When the plant is done making its food, it burps out fresh, clean oxygen for us to breathe.</p>
                       <p>This whole amazing cooking process is called Photosynthesis!</p>`,
                inter: `<p>Photosynthesis is the fundamental biological process by which green plants, algae, and some bacteria convert light energy into chemical energy.</p>
                        <p>This process takes place primarily in the chloroplasts of plant cells, which contain a green pigment called chlorophyll that is responsible for capturing sunlight.</p>
                        <p>The plant absorbs water through its root system and takes in carbon dioxide from the atmosphere through tiny pores in its leaves called stomata.</p>
                        <p>Using the energy from the sun, the plant synthesizes these ingredients to produce glucose (sugar), which serves as its primary energy source for growth and cellular repair.</p>
                        <p>As a byproduct of this chemical reaction, the plant releases oxygen back into the atmosphere, which is essential for the survival of aerobic organisms on Earth.</p>`,
                quick: `<p><strong>Photosynthesis</strong> is an endothermic chemical process where autotrophic organisms use sunlight, water, and carbon dioxide to synthesize glucose and oxygen. It occurs in the chloroplasts and is the primary energy provider for most of Earth's ecosystems.</p>`
            }
        ],
        quizzes: [
            { q: "In the baby analogy, what do plant roots drink from the dirt?", options: ["Milk", "Water", "Juice"], ans: 1 },
            { q: "What do the plant's green leaves catch from the sky?", options: ["Raindrops", "Birds", "Sunlight"], ans: 2 },
            { q: "What gas do plants love to breathe in?", options: ["Oxygen", "Carbon Dioxide", "Helium"], ans: 1 },
            { q: "What kind of food does the plant's magic recipe make?", options: ["Sweet sugar (Glucose)", "Protein", "Vitamins"], ans: 0 },
            { q: "Where does photosynthesis primarily take place inside a plant cell?", options: ["The roots", "The stem", "The chloroplasts"], ans: 2 },
            { q: "What is the green pigment that captures sunlight called?", options: ["Chlorophyll", "Melanin", "Hemoglobin"], ans: 0 },
            { q: "How does carbon dioxide enter the plant leaves?", options: ["Through the roots", "Through tiny pores called stomata", "Through the flowers"], ans: 1 },
            { q: "What is the scientific name for the sugar produced during this process?", options: ["Fructose", "Sucrose", "Glucose"], ans: 2 },
            { q: "What kind of chemical process is photosynthesis?", options: ["Exothermic", "Endothermic", "Combustion"], ans: 1 },
            { q: "What essential gas is released as a byproduct for us to breathe?", options: ["Nitrogen", "Oxygen", "Carbon Dioxide"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Sunlight + Water + CO₂</div>
                    <div class="flow-arrow">⬇️ Enter Chloroplasts</div>
                    <div class="flow-node">Photosynthesis (Energy Conversion)</div>
                    <div class="flow-arrow">⬇️ Produces</div>
                    <div class="flow-node">Glucose (Food) + Oxygen (Byproduct)</div>
                 </div>`
    },
    "stress": {
        levels: [
            {
                baby: "<p>It's okay! Take a deep breath. Imagine blowing a big bubble. Everything will be fine, I promise.</p>",
                inter: "<p>Stress can happen when things feel like too much at once. Try taking a short break, breathing slowly, or focusing on one small task.</p>",
                quick: "<p>Take a 5-minute break. Do box breathing (4s in, 4s hold, 4s out). Rehydrate.</p>"
            }
        ],
        quizzes: [
            { q: "What is a healthy way to manage sudden stress?", options: ["Ignoring it", "Taking slow, deep breaths", "Working harder"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Feeling Overwhelmed</div>
                    <div class="flow-arrow">⬇️ Stop & Pause</div>
                    <div class="flow-node">Deep Breathing Exercises</div>
                    <div class="flow-arrow">⬇️ Result</div>
                    <div class="flow-node">Calm Nervous System</div>
                 </div>`
    },

"gravity": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Have you ever jumped up in the air and wondered why you always come back down?</p>
                       <p>That is because of a massive, invisible magnet called Gravity! It is a superpower that the Earth has.</p>
                       <p>Everything that is heavy has a little bit of this pulling power, but the Earth is so giant that its pull is super strong.</p>
                       <p>Imagine tying a string to a tennis ball and spinning it around your head. The string keeps the ball from flying away.</p>
                       <p>Gravity acts just like that invisible string. It holds you, the trees, the oceans, and the houses firmly on the ground.</p>
                       <p>If we didn't have gravity, everything would just float up into space like a balloon that slipped out of your hand.</p>
                       <p>Even the moon is held in the sky by Earth's gravity. The Earth pulls on the moon so it stays close by, spinning in a circle.</p>
                       <p>But gravity isn't the same everywhere. If you went to the moon, which is smaller than Earth, the pull is much weaker.</p>
                       <p>That is why astronauts can bounce so high when they walk on the moon! The invisible magnet isn't pulling them as hard.</p>`,
                
                // INTER: 4 Paragraphs of technical explanation
                inter: `<p>Gravity is a fundamental force of physics that causes mutual attraction between all things that have mass or energy.</p>
                        <p>Sir Isaac Newton was the first to mathematically describe it. He realized that the same force causing an apple to fall from a tree is the exact same force keeping the moon in orbit around the Earth.</p>
                        <p>The strength of the gravitational pull depends on two things: the mass of the objects and the distance between them. More massive objects have a stronger pull, but as objects get further apart, the force weakens rapidly.</p>
                        <p>On Earth, the acceleration due to gravity is approximately 9.8 meters per second squared. This means if you drop an object, its speed increases by 9.8 m/s every second it falls, ignoring air resistance.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>Gravity</strong> is a fundamental interaction that attracts objects with mass toward each other. Governed by Newton's law of universal gravitation (and Einstein's general relativity), its strength is directly proportional to the masses of the objects and inversely proportional to the square of the distance between their centers. Earth's gravity is 9.8 m/s².</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the baby analogy, what is gravity compared to?", options: ["A giant fan", "An invisible magnet", "A floating balloon"], ans: 1 },
            { q: "What would happen if Earth had no gravity?", options: ["We would float into space", "We would sink into the ground", "Nothing"], ans: 0 },
            { q: "Why can astronauts bounce high on the moon?", options: ["The moon is made of cheese", "The moon has weaker gravity", "They have special boots"], ans: 1 },
            { q: "Which famous scientist mathematically described gravity?", options: ["Albert Einstein", "Nikola Tesla", "Sir Isaac Newton"], ans: 2 },
            { q: "Gravity depends on the distance between objects and their what?", options: ["Color", "Temperature", "Mass"], ans: 2 },
            { q: "What is the approximate acceleration due to gravity on Earth?", options: ["9.8 m/s²", "100 m/s²", "3.14 m/s²"], ans: 0 },
            { q: "Does gravity get stronger or weaker as objects move further apart?", options: ["Stronger", "Weaker", "Stays the same"], ans: 1 },
            { q: "What force keeps the moon in orbit around the Earth?", options: ["Magnetism", "Gravity", "Friction"], ans: 1 },
            { q: "If an object has more mass, does it have a stronger or weaker gravitational pull?", options: ["Stronger", "Weaker", "No difference"], ans: 0 },
            { q: "According to the quick mode, gravity is inversely proportional to what?", options: ["The mass", "The square of the distance", "The speed of light"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Massive Object (Earth)</div>
                    <div class="flow-arrow">⬇️ Generates</div>
                    <div class="flow-node">Gravitational Field (Invisible Pull)</div>
                    <div class="flow-arrow">⬇️ Acts Upon</div>
                    <div class="flow-node">Smaller Objects (Humans, Apples, Moon)</div>
                 </div>`
    },

    "circle": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Imagine you have a giant, delicious pizza right in front of you.</p>
                       <p>If you trace your finger all the way around the outside crust, you just drew a perfect circle!</p>
                       <p>A circle is a super special shape because it has absolutely no corners and no straight edges.</p>
                       <p>It is perfectly round, just like a bicycle wheel, a frisbee, or a shiny coin in your pocket.</p>
                       <p>Right in the very middle of the circle is a secret dot called the 'Center'.</p>
                       <p>If you draw a straight line from the center dot out to the crust, it is called the 'Radius'.</p>
                       <p>The radius is exactly the same length no matter which way you point it, just like the metal spokes on a bike wheel.</p>
                       <p>If you draw a line all the way across the pizza, cutting right through the middle dot to share it with a friend, that is the 'Diameter'.</p>
                       <p>Circles are amazing because their perfect roundness lets wheels roll smoothly so cars and bikes can move super fast!</p>`,
                
                // INTER: 4 Paragraphs of technical explanation
                inter: `<p>In geometry, a circle is a 2D closed shape made up of all points in a plane that are at a given, equal distance from a central point.</p>
                        <p>The distance from the center to any point on the boundary is called the radius (r). The distance straight across the circle, passing directly through the center, is the diameter (d). The diameter is always exactly twice the length of the radius (d = 2r).</p>
                        <p>The outer boundary or perimeter of the circle is known as the circumference (C). To calculate it, we use a fundamental mathematical constant called Pi (π, approximately 3.14159), using the formula C = 2πr.</p>
                        <p>The area (A), which is the amount of 2D space inside the circle, is calculated by multiplying Pi by the square of the radius (A = πr²). Understanding these formulas is essential for everything from engineering wheels to calculating planetary orbits.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>Circle:</strong> A set of all points in a 2D plane that are at a constant distance (radius, r) from a fixed center point. Key properties include the diameter (d = 2r), circumference (C = 2πr), and Area (A = πr²). The constant Pi (π) represents the ratio of any circle's circumference to its diameter.</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the baby analogy, what shape is the crust compared to?", options: ["A square box", "A giant pizza", "A triangle"], ans: 1 },
            { q: "Does a true circle have any corners or straight edges?", options: ["Yes, four corners", "Only one straight edge", "No corners and no straight edges"], ans: 2 },
            { q: "What is the secret dot in the exact middle of the circle called?", options: ["The Radius", "The Center", "The Diameter"], ans: 1 },
            { q: "What do you call a line drawn from the center dot out to the edge?", options: ["The Crust", "The Diameter", "The Radius"], ans: 2 },
            { q: "What do you call a line drawn all the way across the circle that passes through the center?", options: ["The Circumference", "The Diameter", "The Radius"], ans: 1 },
            { q: "What is the perimeter or outer boundary of a circle mathematically called?", options: ["The Area", "The Circumference", "The Volume"], ans: 1 },
            { q: "What special mathematical constant is used to calculate circular measurements?", options: ["Alpha", "Omega", "Pi (π)"], ans: 2 },
            { q: "If the radius is 'r', what is the formula to find the diameter?", options: ["d = r / 2", "d = 2r", "d = r²"], ans: 1 },
            { q: "What is the mathematical formula for the Area of a circle?", options: ["A = 2πr", "A = length × width", "A = πr²"], ans: 2 },
            { q: "What does the constant Pi (π) represent?", options: ["The ratio of a circle's circumference to its diameter", "The radius squared", "The center point"], ans: 0 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Center Point</div>
                    <div class="flow-arrow">⬇️ Measure Outward</div>
                    <div class="flow-node">Radius (Center to Edge)</div>
                    <div class="flow-arrow">⬇️ Double It</div>
                    <div class="flow-node">Diameter (Edge to Edge via Center)</div>
                    <div class="flow-arrow">⬇️ Multiply by Pi (π)</div>
                    <div class="flow-node">Circumference (Outer Perimeter)</div>
                 </div>`
    },

    "statistics": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Imagine you have a giant jar filled with hundreds of colorful jellybeans!</p>
                       <p>If someone asks you, "Which color is the most popular in the jar?", you can't just guess. You have to find out for sure.</p>
                       <p>First, you dump all the jellybeans on the table and sort them into little piles by color. This is called 'Collecting Data'.</p>
                       <p>Next, you count how many jellybeans are in each pile. Ten red, five blue, twenty green! This is called 'Organizing Data'.</p>
                       <p>Then, you draw a pretty picture or a chart with tall blocks to show how many of each color you have.</p>
                       <p>Now, anyone can look at your chart and instantly see that the green block is the tallest without having to count them all over again!</p>
                       <p>You can also find the 'Average'. If you want to share all the jellybeans equally with your friends, you figure out how many everyone gets.</p>
                       <p>Statistics is just the science of counting things, sorting them, and drawing pictures so we can understand a giant mess of information.</p>
                       <p>Thanks to statistics, we know what video games kids like most, what the weather will be like, and how many stars are in the sky!</p>`,
                
                // INTER: 4 Paragraphs of technical explanation
                inter: `<p>Statistics is a branch of applied mathematics that involves the collection, description, analysis, and inference of conclusions from quantitative data.</p>
                        <p>It is generally divided into two main categories: Descriptive statistics and Inferential statistics. Descriptive statistics focus on summarizing the exact data at hand using measures like mean, median, mode, and standard deviation.</p>
                        <p>Inferential statistics, on the other hand, take a random sample of data from a smaller group and use it to make predictions, test hypotheses, or draw logical conclusions about a much larger population.</p>
                        <p>Without statistics, modern science, economics, and machine learning would be impossible. It provides the mathematical framework to identify patterns, calculate probabilities, and make data-driven decisions in an uncertain world.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>Statistics:</strong> The mathematical science of collecting, analyzing, interpreting, and presenting empirical data. It utilizes Descriptive statistics (mean, median, variance) to summarize data sets, and Inferential statistics (hypothesis testing, regression) to draw conclusions about larger populations from sample data, forming the backbone of data science and research.</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the baby analogy, what do the jellybeans represent?", options: ["Information / Data", "Money", "Planets"], ans: 0 },
            { q: "What is sorting the jellybeans into piles called?", options: ["Eating Data", "Organizing Data", "Deleting Data"], ans: 1 },
            { q: "What makes it easy to see the most popular color without counting?", options: ["Drawing a chart or graph", "Closing your eyes", "Guessing"], ans: 0 },
            { q: "If you figure out how to share the jellybeans equally, what are you finding?", options: ["The Average", "The Maximum", "The Speed"], ans: 0 },
            { q: "What are the two main categories of advanced statistics?", options: ["Addition and Subtraction", "Descriptive and Inferential", "Algebra and Calculus"], ans: 1 },
            { q: "Which type of statistics summarizes data using the mean, median, and mode?", options: ["Inferential", "Descriptive", "Magical"], ans: 1 },
            { q: "Which type of statistics uses a sample to make predictions about a larger population?", options: ["Inferential", "Descriptive", "Theoretical"], ans: 0 },
            { q: "What provides the mathematical framework to make data-driven decisions?", options: ["Statistics", "Geometry", "Poetry"], ans: 0 },
            { q: "Is statistics used in Machine Learning?", options: ["Yes", "No", "Only in robots"], ans: 0 },
            { q: "According to the quick mode, what forms the backbone of data science?", options: ["Calculators", "Statistics", "Typing fast"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Raw Data (Messy Information)</div>
                    <div class="flow-arrow">⬇️ Collect & Organize</div>
                    <div class="flow-node">Descriptive Statistics (Charts & Averages)</div>
                    <div class="flow-arrow">⬇️ Analyze & Test</div>
                    <div class="flow-node">Inferential Statistics (Predictions)</div>
                    <div class="flow-arrow">⬇️ Results in</div>
                    <div class="flow-node">Data-Driven Decisions</div>
                 </div>`
    },

    "engineering": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Imagine you have a giant box of building blocks and you want to make a bridge for your toy cars.</p>
                       <p>If you just throw the blocks together without a plan, the bridge might fall down when a heavy toy truck drives on it!</p>
                       <p>So, you have to think carefully. You figure out how wide the bridge needs to be and what block shapes are the strongest.</p>
                       <p>Engineering is exactly like that, but for the real world!</p>
                       <p>Engineers are super-smart builders and problem solvers who use math and science to make our lives better and safer.</p>
                       <p>When scientists discover a new rule about how the world works, engineers take that rule and use it to invent cool new things.</p>
                       <p>Some engineers build giant skyscrapers that touch the clouds, while others build tiny computer chips that go inside your tablet.</p>
                       <p>There are even engineers who design fast rollercoasters, electric cars, and rocket ships that can fly all the way to Mars!</p>
                       <p>Anytime you see something amazing that was built to solve a problem, an engineer was the one who figured out how to make it work.</p>`,
                
                // INTER: 4 Paragraphs of technical explanation
                inter: `<p>Engineering is the application of scientific and mathematical principles to design, build, and maintain structures, machines, materials, devices, systems, and processes.</p>
                        <p>While scientists observe the natural world to discover fundamental laws (like physics and chemistry), engineers apply those discoveries to solve practical human problems and improve society.</p>
                        <p>The field is incredibly diverse and is typically divided into major branches: Civil (infrastructure), Mechanical (machines and motion), Electrical (power and electronics), and Chemical (materials and processes), alongside modern fields like Software and Aerospace.</p>
                        <p>The core of all engineering is the 'engineering design process'. This is a methodical series of steps that includes defining a problem, brainstorming, prototyping, testing, and refining a solution until it is safe, efficient, and cost-effective.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>Engineering:</strong> The practical application of math and science to solve real-world problems. By utilizing the engineering design process (ideation, prototyping, testing, iteration), engineers create everything from civil infrastructure and mechanical engines to software architectures and aerospace vehicles, bridging the gap between scientific theory and practical technology.</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the baby analogy, what are you trying to build with the blocks?", options: ["A toy car", "A bridge for toy cars", "A giant robot"], ans: 1 },
            { q: "What happens if you build the bridge without a careful plan?", options: ["It might fall down", "It turns invisible", "It gets stronger"], ans: 0 },
            { q: "What two things do engineers use to make our lives better?", options: ["Glue and tape", "Math and science", "Paint and wood"], ans: 1 },
            { q: "While scientists discover rules about the world, what do engineers do?", options: ["Write books about them", "Use them to invent new things", "Ignore them"], ans: 1 },
            { q: "What is the primary definition of engineering?", options: ["Applying science and math to design and build", "Studying plants and animals", "Guessing how things work"], ans: 0 },
            { q: "Which branch of engineering focuses on infrastructure like bridges and buildings?", options: ["Chemical", "Mechanical", "Civil"], ans: 2 },
            { q: "Which branch of engineering focuses on machines and motion?", options: ["Electrical", "Mechanical", "Aerospace"], ans: 1 },
            { q: "What is the methodical series of steps engineers use to solve problems called?", options: ["The scientific method", "The engineering design process", "The guessing game"], ans: 1 },
            { q: "What is a crucial step in the engineering design process before a final product is made?", options: ["Prototyping and testing", "Painting it red", "Selling it immediately"], ans: 0 },
            { q: "According to the quick mode, engineering bridges the gap between scientific theory and what?", options: ["Outer space", "Practical technology", "History"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Scientific Theories & Math (The Rules)</div>
                    <div class="flow-arrow">⬇️ Applied via</div>
                    <div class="flow-node">The Engineering Design Process (Plan & Prototype)</div>
                    <div class="flow-arrow">⬇️ To Solve</div>
                    <div class="flow-node">Real-World Human Problems</div>
                    <div class="flow-arrow">⬇️ Results in</div>
                    <div class="flow-node">Practical Technologies (Bridges, Phones, Rockets)</div>
                 </div>`
    },

    "machine learning": {
        levels: [
            {
                // BABY: 9 Paragraphs of simple analogies
                baby: `<p>Imagine you want to teach a cute puppy how to fetch a tennis ball.</p>
                       <p>You cannot just hand the puppy a rulebook to read, because dogs don't understand words like we do!</p>
                       <p>Instead, you throw the ball. When the puppy brings it back, you give it a yummy treat and say 'Good boy!'</p>
                       <p>After practicing this hundreds of times, the puppy learns the pattern: fetching the ball equals getting a treat.</p>
                       <p>Machine Learning works exactly the same way, but instead of a puppy, we are teaching a computer brain!</p>
                       <p>Normally, computers only do exactly what humans type. But with Machine Learning, we don't give them a rulebook.</p>
                       <p>Instead, we give the computer thousands of examples, like showing it pictures of cats and dogs.</p>
                       <p>Every time it guesses right, we give it a digital 'treat' by telling it 'Correct!'</p>
                       <p>Over time, it learns the patterns all by itself. This is how Netflix knows what movies you like!</p>`,
                
                // INTER: 4 Paragraphs of technical explanation
                inter: `<p>Machine Learning (ML) is a powerful subset of Artificial Intelligence that focuses on building systems that learn from historical data.</p>
                        <p>Unlike traditional programming where a developer writes explicit rules (like 'if/else' statements), ML algorithms ingest massive datasets to identify hidden statistical patterns and build predictive models on their own.</p>
                        <p>There are three main types of ML: Supervised Learning (where the training data is labeled with the correct answers), Unsupervised Learning (where the algorithm finds hidden structures in messy, unlabeled data), and Reinforcement Learning (learning through trial and error using rewards).</p>
                        <p>Modern applications of ML include natural language processing (like this AI tutor), computer vision, fraud detection, and predictive analytics. The general rule of ML is: the more high-quality data the model processes, the more accurate its predictions become.</p>`,
                
                // QUICK: 1 Paragraph summary
                quick: `<p><strong>Machine Learning (ML):</strong> A subset of AI where algorithms use statistical models to autonomously learn patterns from data without explicit programming. Key paradigms include Supervised, Unsupervised, and Reinforcement learning. ML powers modern recommendation engines, autonomous vehicles, and Large Language Models.</p>`
            }
        ],
        // 10 Quizzes extracted exactly from the text above
        quizzes: [
            { q: "In the baby analogy, what are you trying to teach?", options: ["A robot to clean", "A puppy to fetch", "A bird to sing"], ans: 1 },
            { q: "Why don't we just give the puppy a rulebook?", options: ["Dogs can't read", "Rulebooks are heavy", "The puppy will eat it"], ans: 0 },
            { q: "Instead of writing explicit rules for a computer, what does Machine Learning do?", options: ["Guesses randomly", "Provides thousands of examples", "Deletes data"], ans: 1 },
            { q: "What is Machine Learning a subset of?", options: ["Artificial Intelligence (AI)", "Web Development", "Hardware Engineering"], ans: 0 },
            { q: "Traditional programming uses explicit rules. What does ML use to find patterns?", options: ["Massive datasets", "Microphones", "Calculators"], ans: 0 },
            { q: "Which type of Machine Learning uses 'labeled' data (like an answer key)?", options: ["Unsupervised Learning", "Supervised Learning", "Reinforcement Learning"], ans: 1 },
            { q: "Which type of ML learns through trial, error, and rewards?", options: ["Reinforcement Learning", "Supervised Learning", "Unsupervised Learning"], ans: 0 },
            { q: "What makes a Machine Learning model's predictions more accurate?", options: ["More high-quality data", "Less data", "A bigger monitor"], ans: 0 },
            { q: "Does a computer using ML need a human to type every single 'if/else' rule?", options: ["Yes", "No, it learns patterns on its own", "Only on weekends"], ans: 1 },
            { q: "What is an example of an ML application mentioned in the text?", options: ["A toaster", "Netflix movie recommendations", "A wooden chair"], ans: 1 }
        ],
        visual: `<div class="flow-container">
                    <div class="flow-node">Historical Data (Thousands of Examples)</div>
                    <div class="flow-arrow">⬇️ Fed Into</div>
                    <div class="flow-node">Machine Learning Algorithm</div>
                    <div class="flow-arrow">⬇️ Discovers Patterns</div>
                    <div class="flow-node">Trained Predictive Model</div>
                    <div class="flow-arrow">⬇️ Analyzes New Data</div>
                    <div class="flow-node">Accurate Real-World Output</div>
                 </div>`
    },

    "hello": {
        levels: [
            {
                // BABY: Friendly, energetic greeting
                baby: `<p>Hi there! 👋 I am your friendly AI buddy!</p>
                       <p>Are you ready to learn something super fun today?</p>
                       <p>Try typing "DSA", "Gravity", or "Photosynthesis" to start our adventure!</p>`,
                
                // INTER: Professional, academic welcome
                inter: `<p>Hello! Welcome to Scholar Alpha. 👋</p>
                        <p>I am your adaptive AI tutor, designed to adjust to your learning pace and explain complex concepts clearly.</p>
                        <p>To get started, please type a curriculum topic like "DSA", "Machine Learning", "Engineering", or "Circle". You can also tell me if you are feeling "Stress".</p>`,
                
                // QUICK: System-style prompt
                quick: `<p><strong>Greetings.</strong> AI Tutor system initialized and ready for input. Try querying "DSA", "Statistics", or "Newton's Laws" to begin.</p>`
            }
        ],
        // Friendly onboarding quizzes!
        quizzes: [
            { q: "What is the best way to start our learning adventure today?", options: ["Staring at the screen in silence 😶", "Typing a fun topic like 'Science' or 'DSA'! 🚀", "Taking a nap 😴"], ans: 1 },
            { q: "If you ever feel overwhelmed or stressed while studying, what can you do?", options: ["Type 'Stress' so we can do a breathing exercise 💙", "Panic!", "Close the app"], ans: 0 }
        ],
        // Welcoming visual flowchart
        visual: `<div class="flow-container">
                    <div class="flow-node" style="border-color: var(--accent-gold);">👋 User Says Hello</div>
                    <div class="flow-arrow">⬇️ System Activates</div>
                    <div class="flow-node" style="border-color: var(--primary);">🧠 Select a Topic (e.g., DSA, Science)</div>
                    <div class="flow-arrow">⬇️ AI Adapts</div>
                    <div class="flow-node" style="border-color: var(--xp-color);">🚀 Learning Begins!</div>
                 </div>`
    },


};

// Add Aliases for emotional support
curriculumDB["sad"] = curriculumDB["stress"];
curriculumDB["sadness"] = curriculumDB["stress"];
curriculumDB["ml"] = curriculumDB["machine learning"];
curriculumDB["ai & ml"] = curriculumDB["machine learning"];
curriculumDB["ai and ml"] = curriculumDB["machine learning"];
// Add these at the bottom of your script if you haven't already!
curriculumDB["hi"] = curriculumDB["hello"];
curriculumDB["hi!"] = curriculumDB["hello"];
curriculumDB["hey"] = curriculumDB["hello"];
curriculumDB["hello!"] = curriculumDB["hello"];
curriculumDB["namaste"] = curriculumDB["hello"];

// --- 2. UI & Login Logic ---
loginBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    if (username !== "") {
        document.getElementById('display-username').textContent = username;
        loginContainer.style.display = 'none';
        chatContainer.style.display = 'flex';
        updateStatsUI();
        triggerAIResponse(`Namaste ${username}! Try asking me about **DSA**, **Photosynthesis**, or tell me if you feel **Stress**.`, 'text');
    } else {
        alert("Please enter a username, bro!");
    }
});

// --- 3. Mode & Difficulty Toggles ---
modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        modeBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentMode = btn.getAttribute('data-mode');
        appendMessage(`*System: Switched to ${currentMode.toUpperCase()} mode*`, 'system-message');
    });
});

diffBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        diffBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentDiff = btn.getAttribute('data-diff');
    });
});

// --- 4. Chat Execution ---
sendBtn.addEventListener('click', handleSendMessage);
userInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSendMessage(); });

function handleSendMessage() {
    const text = userInput.value.trim();
    if (text === "") return;

    appendMessage(text, 'user-message');
    userInput.value = ''; 
    lastTopic = text.toLowerCase();

    setTimeout(() => { generateAIResponse(lastTopic); }, 600); 
}

function appendMessage(htmlContent, className) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', className);
    messageDiv.innerHTML = htmlContent;
    chatBox.appendChild(messageDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// --- 5. Adaptive Core Engine ---
function generateAIResponse(topic) {
    // Safety check for counseling
    if(topic.includes("kill") || topic.includes("hurt")) {
        triggerAIResponse("If you’re feeling overwhelmed, please consider talking to a trusted person like a friend, parent, or teacher immediately.", "text");
        return;
    }

    const data = curriculumDB[topic];

    if (!data) {
        triggerAIResponse(`I am still learning about "${topic}". Try typing "DSA" or "Photosynthesis".`, 'text');
        return;
    }

    if (currentMode === 'quiz') {
        renderQuiz(data.quizzes);
    } else if (currentMode === 'visual') {
        triggerAIResponse(`<strong>Visual Map: ${topic.toUpperCase()}</strong><br>${data.visual}`, 'html');
    } else {
        // Text Mode + Difficulty Progression
        if (!userStats.topicLevels[topic]) userStats.topicLevels[topic] = 0;
        
        let replyText = data.levels[0][currentDiff]; 
        
        let finalHTML = `<div>${replyText}</div>
                         <button class="jump-quiz-btn" onclick="jumpToQuiz()">Take the Master Quiz!</button>`;
        
        triggerAIResponse(finalHTML, 'html');
        gainXP(30);
    }
}

function triggerAIResponse(content, type = 'text') {
    if (type === 'text') {
        appendMessage(`<p>${content}</p>`, 'ai-message');
    } else {
        appendMessage(content, 'ai-message'); 
    }
}

// --- 6. Helper Functions ---
function jumpToQuiz() {
    // Manually switch the UI tab to Quiz
    document.querySelector('[data-mode="quiz"]').click();
    generateAIResponse(lastTopic);
}

function renderQuiz(quizArray) {
    let quizHTML = `<h3 style="color: var(--accent-gold); text-align: center; margin-bottom: 15px;">🎯 Master Quiz</h3>`;
    
    quizArray.forEach((quizObj, index) => {
        quizHTML += `
        <div style="background: #1F2937; padding: 15px; margin-bottom: 15px; border-radius: 8px; border-left: 4px solid var(--primary);">
            <p style="margin-bottom: 10px;"><strong>Q${index + 1}:</strong> ${quizObj.q}</p>
            <div class="quiz-options">`;
            
        quizObj.options.forEach((opt, optIndex) => {
            quizHTML += `<button class="quiz-opt-btn" onclick="checkAnswer(${optIndex}, ${quizObj.ans}, this)">${opt}</button>`;
        });
        
        quizHTML += `</div></div>`;
    });

    triggerAIResponse(quizHTML, 'html');
}

function checkAnswer(selected, correct, btnElement) {
    // Disable all buttons in this specific question block
    const allBtns = btnElement.parentElement.querySelectorAll('.quiz-opt-btn');
    allBtns.forEach(b => b.disabled = true);

    if (selected === correct) {
        btnElement.style.background = "#10B981"; // Green
        gainXP(10); // 10 XP per correct question
    } else {
        btnElement.style.background = "#EF4444"; // Red
        allBtns[correct].style.background = "#10B981"; // Show correct answer
    }
}

function gainXP(amount) {
    userStats.xp += amount;
    if (userStats.xp >= 100) {
        userStats.level++;
        userStats.xp = 0; // Reset XP
        appendMessage(`🎉 LEVEL UP! You are now a Level ${userStats.level} Scholar!`, "system-message");
    }
    updateStatsUI();
}

function updateStatsUI() {
    levelDisplay.textContent = `Level ${userStats.level} Scholar`;
    xpText.textContent = `${userStats.xp} / 100 XP`;
    xpBar.style.width = `${userStats.xp}%`;
}
function getRecommendations(currentTopic) {
    const allTopics = Object.keys(topicDB);
    // Find topics the user hasn't explored much (low count in userStats)
    const unexplored = allTopics.filter(topic => (userStats.topicCounts[topic] || 0) === 0);
    
    if (unexplored.length === 0) return "You've explored everything! Revisit DSA to master it.";

    // Simple Recommendation: Pick the first 2 unexplored topics
    const suggestions = unexplored.slice(0, 2);
    
    let recHTML = `
    <div class="ai-message msg" style="border-left: 4px solid var(--accent-yellow);">
        <p><strong>🚀 Recommended for You:</strong></p>
        <p>Since you're learning about ${currentTopic}, you might like these:</p>
        <div style="display:flex; gap:10px; margin-top:10px;">
            ${suggestions.map(s => `<button class="diff-btn" onclick="sendMessageFromBot('${s}')">${s.toUpperCase()}</button>`).join('')}
        </div>
    </div>`;
    
    return recHTML;
}

// Helper to let the bot "type" for the user
function sendMessageFromBot(topic) {
    document.getElementById('user-input').value = topic;
    sendMessage();
}